// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract AegisBadge {
    struct Badge {
        string label;
        string proofId;
        uint256 timestamp;
        bool isValid;
    }

    mapping(address => Badge) public userBadges;

    // Questa funzione ora usa i tuoi dati specifici
    function emitBadge() public {
        userBadges[msg.sender] = Badge({
            label: "CREDIT WORTHY",
            proofId: "0x00000000000000000000000000000000000000000000000000000000000003e8",
            timestamp: block.timestamp,
            isValid: true
});
    }

    // Funzione per leggere i dati dal frontend
    function getMyBadge(address _user) public view returns (string memory, string memory, uint256) {
        Badge memory b = userBadges[_user];
        return (b.label, b.proofId, b.timestamp);
    }
}