fn main(balance: Field, min_required: pub Field) {
    // Questa riga dimostra che hai abbastanza soldi 
    // SENZA rivelare il saldo esatto (che rimane segreto)
    assert(balance as u64 >= min_required as u64);
}