// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract AegisProtocol {
    // Registra chi può vedere i dati (Viewing Keys)
    mapping(address => bool) public isAuthorizedAuditor;

    event AccessGranted(address indexed user, address indexed auditor);

    function authorizeAuditor(address _auditor) public {
        isAuthorizedAuditor[_auditor] = true;
        emit AccessGranted(msg.sender, _auditor);
    }

    function checkAccess(address _auditor) public view returns (bool) {
        return isAuthorizedAuditor[_auditor];
    }
}